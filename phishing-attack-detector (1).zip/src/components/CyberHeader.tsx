import React from "react";
import { Shield, Activity, LogIn } from "lucide-react";

interface CyberHeaderProps {
  onLoginClick?: () => void;
}

export default function CyberHeader({ onLoginClick }: CyberHeaderProps) {
  const [tickerOffset, setTickerOffset] = React.useState(0);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setTickerOffset((prev) => (prev + 1) % 100);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const alerts = [
    "[SUBMISSION] Dev: Darji Dev | Diploma Civil Engineering | Semester 5th",
    "[CRITICAL] Fresh brand Spoof active: dhl-delivery-processing.top",
    "[WARNING] High density of smishing reported in Europe-West zone",
    "[INTELLIGENCE] Gemini AI Guard model upgraded to v3.5 with semantic audit",
    "[REGISTRY] Secure Student Portal Active - Darji Dev Project"
  ];

  return (
    <header className="border-b border-zinc-800 bg-zinc-950/85 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Logo Brand */}
          <div className="flex items-center space-x-3">
            <div className="relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-lg blur-sm opacity-55 animate-pulse"></div>
              <div className="relative bg-zinc-900 border border-emerald-500/30 p-2 rounded-lg text-emerald-400">
                <Shield className="w-6 h-6" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-mono text-[10px] text-emerald-500 font-semibold tracking-wider uppercase bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  Darji Dev
                </span>
                <span className="text-[10px] font-mono text-zinc-400">Sem 5 • Diploma Civil</span>
              </div>
              <h1 className="text-sm sm:text-lg font-bold text-white tracking-tight flex items-center">
                PhishShield <span className="text-zinc-500 font-light ml-1.5 font-mono text-xs hidden sm:inline">Attack Detector</span>
              </h1>
            </div>
          </div>

          {/* Quick Stats Ticker for Desktop */}
          <div className="hidden md:flex items-center space-x-4 max-w-md overflow-hidden">
            <div className="border border-zinc-850 bg-zinc-900/50 rounded-lg px-3 py-1.5 flex items-center space-x-2.5 overflow-hidden h-9">
              <Activity className="w-3.5 h-3.5 text-cyan-400 animate-pulse shrink-0" />
              <div className="text-left font-mono text-[10px] leading-tight select-none w-48 overflow-hidden relative">
                <span className="text-zinc-400 block truncate">
                  {alerts[tickerOffset % alerts.length]}
                </span>
              </div>
            </div>

            <div className="flex items-center space-x-2 text-[10px] font-mono">
              <div className="flex items-center space-x-1 px-2 py-1 rounded bg-zinc-900 border border-zinc-800 text-zinc-350">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-450 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                </span>
                <span className="uppercase text-[9px] tracking-wider text-emerald-450 font-bold">Secure</span>
              </div>
            </div>
          </div>

          {/* Right Action: Interactive Login Option */}
          <div className="flex items-center space-x-2">
            <button
              onClick={onLoginClick}
              type="button"
              className="flex items-center space-x-1.5 px-3 py-2 sm:px-4 sm:py-2 bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-405 hover:to-teal-405 text-zinc-950 font-bold text-xs sm:text-xs font-mono rounded-lg transition-all duration-150 shadow-md hover:shadow-cyan-500/10 hover:-translate-y-0.5 active:translate-y-0"
              title="Secure Account Gateway"
            >
              <LogIn className="w-3.5 h-3.5 stroke-[2.5px]" />
              <span>LOGIN</span>
            </button>
          </div>
        </div>
      </div>
      
      {/* Visual cyber bottom border loading strip */}
      <div className="h-0.5 w-full bg-gradient-to-r from-emerald-500/60 via-cyan-500/30 to-zinc-900"></div>
    </header>
  );
}
