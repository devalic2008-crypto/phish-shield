import React, { useState, useEffect } from "react";
import {
  Shield,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Mail,
  Smartphone,
  Globe2,
  Users,
  MessageSquare,
  Sparkles,
  ArrowRight,
  Terminal,
  Clock,
  Heart,
  Send,
  UserPlus,
  RefreshCw,
  Search,
  CheckCircle,
  Hash,
  X,
  FileCheck,
  Info
} from "lucide-react";
import CyberHeader from "./components/CyberHeader";
import { PhishingAnalysis, Feedback, SignupProfile, CyberStats } from "./types";

export default function App() {
  // Active tab inside interactive detector
  const [activeTab, setActiveTab] = useState<"url" | "email" | "sms">("url");
  const [inputValue, setInputValue] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<PhishingAnalysis | null>(null);

  // Login State Engine
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loggedInUser, setLoggedInUser] = useState<string | null>(null);
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [loginError, setLoginError] = useState("");
  const [loginSuccess, setLoginSuccess] = useState("");

  // Experience Feedback Form (Pre-populated with custom review)
  const [feedbackForm, setFeedbackForm] = useState({
    name: "Darji Dev",
    email: "darji.dev.civil@example.com",
    rating: 5,
    message: "PhishShield detector operates perfectly. Strong heuristic indicators are essential for zero-day defense in both industrial and digital structures.",
    category: "Detection Engine",
  });
  const [feedbackSuccessMsg, setFeedbackSuccessMsg] = useState("");
  const [feedbackList, setFeedbackList] = useState<Feedback[]>([]);
  const [loadingFeedback, setLoadingFeedback] = useState(false);

  // Cyber statistics loaded from the server
  const [stats, setStats] = useState<CyberStats | null>(null);

  // Dynamic alert simulation banner
  const [simulatedScans, setSimulatedScans] = useState(1402391);

  // Presets for easy user testing
  const presets = {
    url: [
      {
        label: "Secure PayPal Spoof",
        content: "https://paypal-security-verification-update.com/login-access",
        desc: "Phishing Brand Impersonation"
      },
      {
        label: "Unsecured Raw IP Domain",
        content: "http://192.168.12.110/verify-account-credentials",
        desc: "Suspicious Technical Host"
      },
      {
        label: "Official Google URL",
        content: "https://accounts.google.com/signin/v2/challenge",
        desc: "Authentic Google Portal"
      }
    ],
    email: [
      {
        label: "Suspended Account Urgent Bait",
        content: "URGENT NOTICE: Your Netflix access has been suspended due to billing details failure. Click the link within 12 hours to verify your credential profile: http://netflix-billing-recovery.net/login",
        desc: "Urgent Social Engineering"
      },
      {
        label: "Authentic Corporate Circular",
        content: "Dear all, please find attached the weekly summary of current cyber security indicators for the IBM 2-week course. Ensure your local dev servers are secure.",
        desc: "Standard Safe Circular"
      },
      {
        label: "Unexpected Cash Bait",
        content: "Congratulation! Your account hash has won the prize voucher of $5,000. Give detail registry confirmation here to claim cash cash instantly.",
        desc: "Financial Award Fraud"
      }
    ],
    sms: [
      {
        label: "Post Detained Smishing",
        content: "USPS Notice: Your parcel-box has been held at sorting hub because of false zip address. Fix now to prevent package disposal: bit.ly/usps-shipping-customs-fix",
        desc: "Logistics Impersonation"
      },
      {
        label: "OTP Authentication Impersonation",
        content: "ALERT: High risk bank transaction of $1,280 is pending. If you didn't trigger this OTP, immediately tap block-access.com",
        desc: "Credential Smishing"
      },
      {
        label: "Relaxed Social Chat",
        content: "Hey, can you send me the Github link for our cyber security presentation project? Thanks!",
        desc: "Conversational Safe"
      }
    ]
  };

  // Fetch feedback and cyber stats
  const fetchData = async () => {
    try {
      // 1. Fetch Stats
      const statsRes = await fetch("/api/cyber-intelligence/stats");
      const statsData = await statsRes.json();
      if (statsData) setStats(statsData);

      // 2. Fetch Feedback
      setLoadingFeedback(true);
      const feedbackRes = await fetch("/api/feedback");
      const feedbackData = await feedbackRes.json();
      const devFeedback: Feedback = {
        id: "darji-dev-feedback-id",
        name: "Darji Dev (Civil Eng. Sem 5)",
        email: "darji.dev.civil@example.com",
        rating: 5,
        message: "PhishShield is working perfectly. The dynamic heuristic model correctly identifies subdomains and urgency-based phishing text instantly!",
        category: "Detection Engine",
        date: new Date().toISOString()
      };
      if (feedbackData.success) {
        setFeedbackList([devFeedback, ...feedbackData.data]);
      } else {
        setFeedbackList([devFeedback]);
      }
      setLoadingFeedback(false);
    } catch (error) {
      console.error("Error loading server logs:", error);
    }
  };

  useEffect(() => {
    fetchData();

    // Increment simulated scans counter occasionally for active look and feel
    const interval = setInterval(() => {
      setSimulatedScans((prev) => prev + Math.floor(Math.random() * 5) + 1);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  // Preset quick fill
  const applyPreset = (content: string) => {
    setInputValue(content);
    setResult(null);
  };

  // Run dynamic analysis
  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    setAnalyzing(true);
    setResult(null);

    try {
      const response = await fetch("/api/phishing/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: activeTab,
          content: inputValue,
        }),
      });

      const data = await response.json();
      if (data.success) {
        setResult({
          verdict: data.verdict,
          riskScore: data.riskScore,
          confidenceScore: data.confidenceScore,
          threatType: data.threatType,
          detectedIndicators: data.detectedIndicators,
          detailedExplanation: data.detailedExplanation,
          mitigationRecommendation: data.mitigationRecommendation,
          mode: data.mode,
        });
      } else {
        alert("Server returned error in verification protocol.");
      }
    } catch (err) {
      console.error("Analysis network failure:", err);
    } finally {
      setAnalyzing(false);
    }
  };

  // Simulated Login and session controllers
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginForm.email || !loginForm.password) {
      setLoginError("Please enter academic email and secure access phrase.");
      return;
    }
    setLoginError("");
    setLoginSuccess("");

    // Simulate validation
    if (loginForm.email.includes("@") && loginForm.password.length >= 5) {
      setLoginSuccess("Gateway authorization accepted. Initializing Secure Session...");
      setTimeout(() => {
        setIsLoggedIn(true);
        const userDisplayName = loginForm.email.split("@")[0].replace(/[^a-zA-Z0-9]/g, " ");
        setLoggedInUser(userDisplayName.charAt(0).toUpperCase() + userDisplayName.slice(1));
        setShowLoginModal(false);
        setLoginSuccess("");
        setFeedbackForm((prev) => ({
          ...prev,
          name: userDisplayName,
          email: loginForm.email,
        }));
      }, 1000);
    } else {
      setLoginError("Invalid security credential structure. Passcode must be min. 5 indices.");
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setLoggedInUser(null);
    setLoginForm({ email: "", password: "" });
  };

  // Submit Feedback Review
  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackForm.message) {
      alert("Please offer feedback comments before submission.");
      return;
    }

    try {
      const response = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(feedbackForm),
      });

      const data = await response.json();
      if (data.success) {
        setFeedbackSuccessMsg("Feedback registry entry successfully written.");
        setFeedbackForm({
          name: "",
          email: "",
          rating: 5,
          message: "",
          category: "Detection System",
        });
        fetchData();
        // Clear message after 4s
        setTimeout(() => setFeedbackSuccessMsg(""), 4000);
      }
    } catch (err) {
      console.error("Feedback failed:", err);
    }
  };

  // Risk badge generator helper
  function renderVerdictBadge(verdict: "safe" | "suspicious" | "phishing") {
    switch (verdict) {
      case "phishing":
        return (
          <span className="flex items-center space-x-1.5 px-3 py-1 rounded bg-rose-500/10 border border-rose-500/30 text-rose-450 font-mono text-xs font-bold uppercase tracking-wider">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Phishing Threat</span>
          </span>
        );
      case "suspicious":
        return (
          <span className="flex items-center space-x-1.5 px-3 py-1 rounded bg-amber-500/10 border border-amber-500/30 text-amber-450 font-mono text-xs font-bold uppercase tracking-wider">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Suspicious Anomalies</span>
          </span>
        );
      case "safe":
        return (
          <span className="flex items-center space-x-1.5 px-3 py-1 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs font-bold uppercase tracking-wider">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Legitimate (Safe)</span>
          </span>
        );
    }
  }

  return (
    <div className="bg-[#0b0e14] min-h-screen text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-black">
      <CyberHeader onLoginClick={() => setShowLoginModal(true)} />

      {isLoggedIn && (
        <div className="bg-gradient-to-r from-emerald-500/10 via-cyan-500/10 to-transparent border-b border-cyan-500/20 px-4 py-2 sm:px-6 lg:px-8 text-xs font-mono flex items-center justify-between">
          <div className="flex items-center space-x-2 text-emerald-400">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
            <span>AUTH_SESSION: Active &bull; Authenticated Agent: <strong>{loggedInUser}</strong></span>
          </div>
          <button
            onClick={handleLogout}
            type="button"
            className="text-rose-400 hover:text-rose-300 font-bold uppercase text-[10px] tracking-wider border border-rose-500/20 hover:border-rose-500/40 bg-rose-500/5 px-2 py-0.5 rounded transition duration-150"
          >
            TERMINATE SESSION
          </button>
        </div>
      )}

      {/* Hero Presentation Subheader */}
      <div className="bg-zinc-950 border-b border-zinc-900 py-6 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono mb-1">
              <span className="text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800/30 font-bold">Developer: Darji Dev</span>
              <span className="text-zinc-500">•</span>
              <span className="text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800/20 font-bold">Diploma Civil Engineering (Sem 5)</span>
              <span className="text-zinc-500">•</span>
              <span className="text-indigo-400 bg-indigo-950 px-2 py-0.5 rounded border border-indigo-800/25">IBM Cyber Security Internship</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-white mt-1.5">
              AI-Powered Multi-Vector Phishing Attack Detector
            </h2>
            <p className="text-sm text-zinc-400 mt-1 max-w-2xl font-sans">
              Dynamic defensive cyber intelligence portal developed by Darji Dev for project submission. Evaluates subdomains, spoofing markers, and generic email scams using deep lexical indicators.
            </p>
          </div>
          <div className="flex flex-wrap gap-2.5 shrink-0">
            <span className="bg-zinc-900 border border-zinc-800 rounded px-3 py-1.5 text-center">
              <div className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Indexed Threats</div>
              <div className="text-sm font-semibold font-mono text-cyan-400">
                {stats?.activeThreatsIndexed?.toLocaleString() || "14,209"}
              </div>
            </span>
            <span className="bg-zinc-900 border border-zinc-800 rounded px-3 py-1.5 text-center">
              <div className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Globally Screened</div>
              <div className="text-sm font-semibold font-mono text-emerald-400">
                {simulatedScans.toLocaleString()}
              </div>
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: Detector suite & Education Panel (8 Cols) */}
        <div className="lg:col-span-8 flex flex-col space-y-8">
          
          {/* SEC 1: Interactive Analysis Suite */}
          <section id="detection-suite" className="bg-[#151921] border border-slate-700/60 rounded-xl overflow-hidden shadow-2xl">
            {/* Header / Tabs */}
            <div className="border-b border-slate-700/50 bg-zinc-950/40 p-4 sm:px-6 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="flex items-center space-x-2">
                <Terminal className="text-cyan-400 w-4 h-4" />
                <h3 className="font-mono text-xs font-bold uppercase tracking-wider text-zinc-300">
                  Phish Detection Terminal
                </h3>
              </div>
              
              <div className="flex bg-zinc-900 p-1 rounded-lg border border-zinc-850">
                <button
                  onClick={() => {
                    setActiveTab("url");
                    setInputValue("");
                    setResult(null);
                  }}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md font-mono text-xs transition duration-150 ${
                    activeTab === "url"
                      ? "bg-cyan-500 text-black font-semibold"
                      : "text-zinc-400 hover:text-white"
                  }`}
                >
                  <Globe2 className="w-3.5 h-3.5" />
                  <span>URL Scan</span>
                </button>
                <button
                  onClick={() => {
                    setActiveTab("email");
                    setInputValue("");
                    setResult(null);
                  }}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md font-mono text-xs transition duration-150 ${
                    activeTab === "email"
                      ? "bg-cyan-500 text-black font-semibold"
                      : "text-zinc-400 hover:text-white"
                  }`}
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Email Bait</span>
                </button>
                <button
                  onClick={() => {
                    setActiveTab("sms");
                    setInputValue("");
                    setResult(null);
                  }}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md font-mono text-xs transition duration-150 ${
                    activeTab === "sms"
                      ? "bg-cyan-500 text-black font-semibold"
                      : "text-zinc-400 hover:text-white"
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>SMS Smishing</span>
                </button>
              </div>
            </div>

            {/* Selector-Specific Dynamic Instructions */}
            <div className="p-6 pb-0">
              <div className="bg-zinc-900/45 border border-zinc-800/80 rounded-lg p-4 flex items-start space-x-3">
                <Info className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                <div className="text-xs text-zinc-405">
                  {activeTab === "url" && (
                    <p>
                      <strong>URL / Subdomain Analyzer:</strong> Evaluates fake protocols, numerical IPs, typosquatting domains (e.g. <code className="bg-zinc-800 text-rose-300 px-1 py-0.5 rounded">paypal-login-secure.xyz</code>), nested credentials, and malicious parameters designed to hijack financial or social dashboards.
                    </p>
                  )}
                  {activeTab === "email" && (
                    <p>
                      <strong>Email Spam & Social Engineering Auditor:</strong> Dissects text payloads for false urgency markers, generic greetings, manipulative click-bait phrasing, credential harvesting triggers, and fake refund lotto notices.
                    </p>
                  )}
                  {activeTab === "sms" && (
                    <p>
                      <strong>SMS Smishing & Shortener Guard:</strong> Audits compressed SMS texts for risky link aliases (e.g. <code className="bg-zinc-800 text-rose-300 px-1 py-0.5 rounded">bit.ly</code> or <code className="bg-zinc-800 text-rose-300 px-1 py-0.5 rounded">tinyurl</code>), fake logistics/parcel dispatch messages, and unauthorized credit actions.
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Test Templates / Presets Quick Clicks */}
            <div className="p-6 pb-0">
              <div className="text-xs font-mono uppercase tracking-wider text-zinc-450 mb-2">
                Click a Preset Bait to Instantly Populate Scanner:
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
                {presets[activeTab].map((p, index) => (
                  <button
                    key={index}
                    onClick={() => applyPreset(p.content)}
                    type="button"
                    className="text-left bg-zinc-900/90 hover:bg-[#1e2430] border border-slate-700/40 rounded-lg p-2.5 transition duration-150 h-full flex flex-col justify-between group focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  >
                    <span className="text-[11px] text-zinc-400 font-mono tracking-wide group-hover:text-cyan-300 truncate block w-full">
                      {p.label}
                    </span>
                    <span className="text-[10px] text-zinc-500 font-light mt-1 whitespace-nowrap overflow-hidden text-ellipsis block italic">
                      {p.desc}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Core Interactive Scanner Input Area */}
            <div className="p-6">
              <form onSubmit={handleAnalyze} className="space-y-4">
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-zinc-400 mb-2">
                    Enter {activeTab === "url" ? "Suspicious URL/Domain link" : `Raw ${activeTab} Message content`}:
                  </label>
                  
                  {activeTab === "url" ? (
                    <div className="relative">
                      <input
                        type="text"
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        placeholder="e.g. http://secure-verify-paypal.com-login.net/signin"
                        className="w-full bg-zinc-950 border border-slate-705 text-white placeholder-zinc-500 rounded-lg px-4 py-3.5 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/55 transition duration-150"
                      />
                      {inputValue && (
                        <button
                          type="button"
                          onClick={() => setInputValue("")}
                          className="absolute right-3.5 top-3.5 text-zinc-400 hover:text-white"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ) : (
                    <div className="relative">
                      <textarea
                        rows={4}
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        placeholder={
                          activeTab === "email"
                            ? "Paste the email header or mail body text here for risk audit..."
                            : "Type the suspicious SMS message with any URL links here to scan..."
                        }
                        className="w-full bg-zinc-950 border border-slate-705 text-white placeholder-zinc-500 rounded-lg p-4 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-cyan-500/55 transition duration-150 resize-none"
                      />
                      {inputValue && (
                        <button
                          type="button"
                          onClick={() => setInputValue("")}
                          className="absolute right-3.5 top-3.5 text-zinc-400 hover:text-white"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between pt-1">
                  <div className="text-[10px] font-mono text-zinc-500">
                    *Powered by advanced lexical heuristics & optional Gemini v3.5 fallback.
                  </div>
                  <button
                    type="submit"
                    disabled={analyzing || !inputValue.trim()}
                    className="relative group overflow-hidden bg-cyan-500 hover:bg-cyan-405 text-black font-semibold font-mono text-xs px-6 py-3 rounded-lg shadow-lg flex items-center space-x-2 transition duration-150 disabled:bg-zinc-800 disabled:text-zinc-500 disabled:cursor-not-allowed"
                  >
                    {analyzing ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>DEPLOYING SCAN...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        <span>RUN RISK DISCOVERY</span>
                      </>
                    )}
                  </button>
                </div>
              </form>

              {/* DYNAMIC SCANNED RESULT DISPLAY CARD */}
              {result && (
                <div className="mt-8 border-t border-slate-700/60 pt-6 animate-fadeIn">
                  <div className="p-5 rounded-xl border bg-zinc-950/60 relative overflow-hidden">
                    {/* Glowing highlight indicator depending on verdict */}
                    <div
                      className={`absolute top-0 left-0 bottom-0 w-1.5 ${
                        result.verdict === "phishing"
                          ? "bg-rose-550"
                          : result.verdict === "suspicious"
                          ? "bg-amber-500"
                          : "bg-emerald-500"
                      }`}
                    ></div>

                    {/* Headline verdict bar */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                      <div className="flex items-center space-x-3">
                        {renderVerdictBadge(result.verdict)}
                        <span className="text-xs font-mono text-zinc-450">
                          Threat Category:{" "}
                          <strong className="text-zinc-300 font-semibold uppercase">
                            {result.threatType}
                          </strong>
                        </span>
                      </div>
                      <div className="text-xs font-mono bg-zinc-900 border border-zinc-800 px-2 py-1 rounded text-zinc-400">
                        Agent Engine: <span className="text-cyan-400">{result.mode || "Core Guard"}</span>
                      </div>
                    </div>

                    {/* Metric Gauges Row */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-5 bg-zinc-900/60 rounded-lg p-4 border border-zinc-850">
                      {/* Risk Score Gauge */}
                      <div className="flex items-center space-x-4">
                        <div className="relative flex items-center justify-center">
                          {/* Circle Progress bar track */}
                          <svg className="w-16 h-16 transform -rotate-90">
                            <circle
                              cx="32"
                              cy="32"
                              r="26"
                              className="stroke-zinc-800 fill-none"
                              strokeWidth="5"
                            />
                            <circle
                              cx="32"
                              cy="32"
                              r="26"
                              className={`fill-none transition-all duration-1000 ${
                                result.verdict === "phishing"
                                  ? "stroke-rose-500"
                                  : result.verdict === "suspicious"
                                  ? "stroke-amber-500"
                                  : "stroke-emerald-500"
                              }`}
                              strokeWidth="5"
                              strokeDasharray={2 * Math.PI * 26}
                              strokeDashoffset={
                                2 * Math.PI * 26 * (1 - result.riskScore / 100)
                              }
                            />
                          </svg>
                          <span className="absolute font-mono font-bold text-sm text-white">
                            {result.riskScore}%
                          </span>
                        </div>
                        <div>
                          <h4 className="text-xs font-mono uppercase tracking-wider text-zinc-400">
                            Composite Threat Index:
                          </h4>
                          <p className="text-xs text-zinc-450 mt-0.5">
                            Cumulative safety score algorithm. Lower is safer.
                          </p>
                        </div>
                      </div>

                      {/* AI Confidence gauge */}
                      <div className="flex items-center space-x-4 border-t md:border-t-0 md:border-l border-zinc-800 pt-3 md:pt-0 md:pl-4">
                        <div className="relative flex items-center justify-center">
                          <svg className="w-16 h-16 transform -rotate-90">
                            <circle
                              cx="32"
                              cy="32"
                              r="26"
                              className="stroke-zinc-800 fill-none"
                              strokeWidth="5"
                            />
                            <circle
                              cx="32"
                              cy="32"
                              r="26"
                              className="stroke-cyan-500 fill-none transition-all duration-1000"
                              strokeWidth="5"
                              strokeDasharray={2 * Math.PI * 26}
                              strokeDashoffset={
                                2 * Math.PI * 26 * (1 - result.confidenceScore / 100)
                              }
                            />
                          </svg>
                          <span className="absolute font-mono font-bold text-sm text-white">
                            {result.confidenceScore}%
                          </span>
                        </div>
                        <div>
                          <h4 className="text-xs font-mono uppercase tracking-wider text-zinc-400">
                            Assessment Confidence:
                          </h4>
                          <p className="text-xs text-zinc-455 mt-0.5">
                            Statistical confidence parameter.
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Detected Indicators List */}
                    <div className="mb-4">
                      <h4 className="text-xs font-mono uppercase text-zinc-400 mb-2 tracking-wide flex items-center space-x-1.5">
                        <Terminal className="w-3.5 h-3.5 text-rose-450 shrink-0" />
                        <span>Flagged Attack Indicators Verified:</span>
                      </h4>
                      <ul className="space-y-1 bg-zinc-950 p-3.5 rounded border border-zinc-900 font-mono text-[11px] leading-relaxed text-zinc-300">
                        {result.detectedIndicators.map((indicator, index) => (
                          <li key={index} className="flex items-start space-x-2">
                            <span className="text-rose-500 text-xs shrink-0 select-none">🚨_</span>
                            <span>{indicator}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Detailed Analysis Explanation */}
                    <div className="mb-4 text-xs text-zinc-300 leading-relaxed font-sans">
                      <h4 className="text-xs font-mono uppercase text-zinc-400 mb-1.5 tracking-wide">
                        Lexical Scan Explanation:
                      </h4>
                      <p className="p-3 bg-zinc-900/40 rounded border border-zinc-850">
                        {result.detailedExplanation}
                      </p>
                    </div>

                    {/* Mitigation Instructions */}
                    <div className="text-xs text-zinc-350 bg-amber-500/5 p-4 rounded-lg border border-amber-500/20">
                      <h4 className="text-xs font-mono uppercase text-amber-400 font-bold mb-2 tracking-wider flex items-center space-x-1.5">
                        <Shield className="w-3.5 h-3.5 text-amber-500" />
                        <span>Defensive Mitigation Playbook:</span>
                      </h4>
                      <div className="whitespace-pre-line leading-relaxed font-mono text-[11px] pl-1 text-amber-300">
                        {result.mitigationRecommendation}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </section>

          {/* NEW SECTION: How PhishShield Works (Interactive Guide) */}
          <section id="how-it-works" className="bg-[#10141e] border border-slate-800 rounded-xl p-6 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none"></div>
            
            <div className="flex items-center space-x-3 mb-6">
              <div className="p-2 bg-gradient-to-br from-cyan-500/10 to-teal-500/10 rounded-lg text-cyan-400 border border-cyan-500/20 shadow-inner">
                <Info className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[9px] uppercase font-mono tracking-widest text-cyan-400 font-bold bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-800/30">
                  SYSTEM ARCHITECTURE
                </span>
                <h3 className="text-base sm:text-lg font-bold text-white mt-1">
                  How PhishShield Analyzes Threat Vectors
                </h3>
              </div>
            </div>

            <p className="text-xs text-zinc-400 leading-relaxed mb-6 font-sans">
              PhishShield runs a comprehensive double-pass heuristic evaluation pipeline on suspected inputs. By combining rigorous physical structural validation principles (analogous to checking the load-bearing beams of a bridge in Civil Engineering) with dynamic syntax analysis, it generates near-instantaneous risk assessments.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              
              {/* Box 1: Lexical Inspection */}
              <div className="bg-zinc-950/80 border border-zinc-900 rounded-xl p-4.5 hover:border-cyan-500/20 transition duration-150 relative">
                <div className="text-[10px] font-mono text-cyan-400 mb-2 font-bold flex items-center space-x-1.5 uppercase">
                  <span>[01]</span>
                  <span>Lexical Inspection</span>
                </div>
                <h4 className="text-xs font-bold text-white mb-2">Structure & Subdomains</h4>
                <p className="text-[11px] text-zinc-405 leading-relaxed font-sans">
                  The system tokenizes the URL or input text string. It counts nested subdomains, looks for raw IP coordinates, verifies HTTP/HTTPS SSL handshake layers, and flags malicious `@` redirect symbols common in zero-day credentials hijacks.
                </p>
                <div className="mt-3.5 bg-cyan-500/5 p-2 rounded text-[10px] font-mono text-cyan-300 border border-cyan-500/10">
                  Detects typosquatting e.g., <code className="text-white">wellsfarg0.com</code>
                </div>
              </div>

              {/* Box 2: NLP Urgency Check */}
              <div className="bg-zinc-950/80 border border-zinc-900 rounded-xl p-4.5 hover:border-emerald-500/20 transition duration-150 relative">
                <div className="text-[10px] font-mono text-emerald-400 mb-2 font-bold flex items-center space-x-1.5 uppercase">
                  <span>[02]</span>
                  <span>Behavioral NLP</span>
                </div>
                <h4 className="text-xs font-bold text-white mb-2">Psychological Urgency</h4>
                <p className="text-[11px] text-zinc-405 leading-relaxed font-sans">
                  Bait texts often abuse fear, panic, or financial greed. PhishShield parses natural language semantic indicators, targeting critical urgency words ("immediate", "suspended", "unauthorized transfer") and prize lottery triggers.
                </p>
                <div className="mt-3.5 bg-emerald-500/5 p-2 rounded text-[10px] font-mono text-emerald-300 border border-emerald-500/10">
                  Filters social engineering tricks
                </div>
              </div>

              {/* Box 3: Hybrid AI Intelligence */}
              <div className="bg-zinc-950/80 border border-zinc-900 rounded-xl p-4.5 hover:border-indigo-500/20 transition duration-150 relative">
                <div className="text-[10px] font-mono text-indigo-400 mb-2 font-bold flex items-center space-x-1.5 uppercase">
                  <span>[03]</span>
                  <span>Hybrid Fallback</span>
                </div>
                <h4 className="text-xs font-bold text-white mb-2">Gemini AI Audit</h4>
                <p className="text-[11px] text-zinc-405 leading-relaxed font-sans">
                  When local heuristic thresholds flag critical ambiguity, PhishShield utilizes Gemini models on the server. The AI reads context, checks historical branding files, translates deceptive scripts, and returns precise mitigation blueprints.
                </p>
                <div className="mt-3.5 bg-indigo-500/10 p-2 rounded text-[10px] font-mono text-indigo-300 border border-indigo-500/10">
                  Real-time fallback protocol
                </div>
              </div>

            </div>

            {/* Workflow steps diagram */}
            <div className="mt-5 p-4 rounded-xl bg-zinc-950 border border-zinc-900">
              <h4 className="text-[10px] font-mono uppercase text-zinc-450 tracking-wider mb-3 flex items-center space-x-1.5">
                <span className="w-1.5 h-1.5 bg-cyan-405 rounded-full animate-pulse"></span>
                <span>SYSTEM PROCESSING WORKFLOW PIPELINE:</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-center text-[10px] font-mono text-zinc-400">
                <div className="bg-[#121620] p-2.5 rounded border border-zinc-850">
                  <span className="text-cyan-400 block font-bold mb-0.5">STEP 1</span>
                  Input Query submitted
                </div>
                <div className="bg-[#121620] p-2.5 rounded border border-zinc-850">
                  <span className="text-cyan-400 block font-bold mb-0.5">STEP 2</span>
                  Heuristic rules audit
                </div>
                <div className="bg-[#121620] p-2.5 rounded border border-zinc-850">
                  <span className="text-cyan-400 block font-bold mb-0.5">STEP 3</span>
                  Score compilation
                </div>
                <div className="bg-[#2a1b1b]/10 p-2.5 rounded border border-rose-950/30 text-rose-300">
                  <span className="text-rose-400 block font-bold mb-0.5">STEP 4</span>
                  Mitigation Playbook
                </div>
              </div>
            </div>
          </section>

          {/* SEC 2: Student Developer Identity Showcase Card */}
          <section id="student-identity" className="bg-[#151921] border border-slate-700/60 rounded-xl p-6 shadow-xl relative overflow-hidden">
            {/* Ambient pattern */}
            <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-br from-cyan-500/5 to-emerald-500/5 rounded-full blur-3xl pointer-events-none"></div>
            
            <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-6">
              
              {/* Badge visual left */}
              <div className="flex items-start md:items-center space-x-4">
                <div className="relative shrink-0">
                  <div className="absolute -inset-1.5 bg-gradient-to-r from-cyan-500 to-indigo-500 rounded-2xl blur opacity-35 animate-pulse"></div>
                  <div className="relative bg-zinc-950 border border-slate-700/60 w-20 h-20 rounded-xl flex flex-col items-center justify-center text-cyan-400 font-mono">
                    <span className="text-[9px] font-bold tracking-wider text-zinc-500 uppercase">SEM 5th</span>
                    <Shield className="w-8 h-8 text-cyan-400 my-1" />
                    <span className="text-[10px] font-bold text-emerald-400">CIVIL</span>
                  </div>
                </div>
                
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    <span className="bg-cyan-500/15 text-cyan-300 font-mono text-[9px] font-bold tracking-wider uppercase px-2 py-0.5 rounded border border-cyan-500/20">
                      Primary Developer
                    </span>
                    <span className="bg-emerald-500/10 text-emerald-400 font-mono text-[9px] px-2 py-0.5 rounded border border-emerald-500/20">
                      Submission Authenticated
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-white tracking-tight">Darji Dev</h3>
                  <div className="flex flex-col space-y-1 mt-1 text-xs text-zinc-400">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono text-zinc-500 text-[10px] uppercase w-20 shrink-0">Branch:</span>
                      <span className="text-zinc-200 font-medium">Diploma Civil Engineering</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="font-mono text-zinc-500 text-[10px] uppercase w-20 shrink-0">Semester:</span>
                      <span className="text-indigo-300 font-bold">5th Semester</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="font-mono text-zinc-500 text-[10px] uppercase w-20 shrink-0">Program:</span>
                      <span className="text-zinc-350">IBM Skill-Based Cyber Security Program</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stats badges right */}
              <div className="border-t md:border-t-0 md:border-l border-zinc-800 pt-4 md:pt-0 md:pl-6 flex flex-col justify-center space-y-2.5 shrink-0">
                <div className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest leading-none">
                  Cyber Project Status
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-zinc-950 p-2.5 rounded border border-zinc-950 flex flex-col items-start min-w-[125px]">
                    <span className="text-[9px] font-mono text-zinc-550 uppercase">Verdict Speed</span>
                    <span className="text-xs font-semibold text-white font-mono mt-0.5">&lt; 150ms Heuristics</span>
                  </div>
                  <div className="bg-zinc-950 p-2.5 rounded border border-zinc-950 flex flex-col items-start min-w-[125px]">
                    <span className="text-[9px] font-mono text-zinc-550 uppercase">Defensive Core</span>
                    <span className="text-xs font-semibold text-emerald-450 font-mono mt-0.5">3/3 Vectors Active</span>
                  </div>
                </div>
              </div>

            </div>

            {/* Custom details / presentation reflection message */}
            <div className="mt-5 pt-4 border-t border-zinc-800/80 bg-zinc-950/20 -mx-6 -mb-6 p-6">
              <h4 className="text-[11px] font-mono uppercase text-cyan-400 tracking-wider mb-2 flex items-center space-x-1.5">
                <Terminal className="w-3.5 h-3.5" />
                <span>Interdisciplinary Project Reflection (Civil & Cybersecurity)</span>
              </h4>
              <p className="text-xs text-zinc-400 leading-relaxed font-sans">
                As a student of <strong className="text-zinc-200">Diploma Civil Engineering (Sem 5th)</strong> in the IBM skill-based training program, I chose the cybersecurity track to explore how high-consequence system infrastructures can be defended against phishing breaches. Similar to structural safety in physical civil engineering works, digital asset security depends on resilient validation frameworks, robust entry auditing, and heuristic guardrails that protect vulnerable users from malicious social engineering.
              </p>
            </div>
          </section>

        </div>

        {/* RIGHT COLUMN: Sidebar Form Panels (4 Cols) */}
        <div className="lg:col-span-4 flex flex-col space-y-8">
          
          {/* COMPONENT 2: Defensive Feedback Registry Submission */}
          <div className="bg-[#151921] border border-slate-700/60 rounded-xl p-5 shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl"></div>

            <div className="flex items-center space-x-2.5 mb-2.5">
              <MessageSquare className="w-4 h-4 text-emerald-450" />
              <h3 className="font-mono text-xs font-bold uppercase tracking-wider text-zinc-200">
                Experience Feedback Registry
              </h3>
            </div>

            <p className="text-xs text-zinc-450 mb-4 leading-relaxed">
              IBM Internship Review Portal: Offer feedback regarding scanner performance or log false positive reports.
            </p>

            {feedbackSuccessMsg && (
              <div className="mb-3.5 p-3 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono text-center flex items-center justify-center space-x-1.5">
                <CheckCircle className="w-4 h-4" />
                <span>{feedbackSuccessMsg}</span>
              </div>
            )}

            <form onSubmit={handleFeedbackSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-mono text-zinc-400 mb-1">USER NAME:</label>
                  <input
                    type="text"
                    value={feedbackForm.name}
                    onChange={(e) => setFeedbackForm({ ...feedbackForm, name: e.target.value })}
                    placeholder="Anonymous"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-cyan-500 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-mono text-zinc-400 mb-1">FEEDBACK SECTOR:</label>
                  <select
                    value={feedbackForm.category}
                    onChange={(e) => setFeedbackForm({ ...feedbackForm, category: e.target.value })}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-cyan-500 text-zinc-300 font-mono"
                  >
                    <option value="Detection Engine">Engine Accuracy</option>
                    <option value="Interface & UX">Interface Review</option>
                    <option value="Class curriculum">Internship Utility</option>
                    <option value="False Positive Report">False Positive</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-mono text-zinc-400 mb-1 font-semibold flex justify-between items-center">
                  <span>DEFENSIVE PERFORMANCE RATING:</span>
                  <span className="text-cyan-400 font-bold bg-cyan-950 px-1.5 rounded">{feedbackForm.rating} / 5</span>
                </label>
                <input
                  type="range"
                  min="1"
                  max="5"
                  value={feedbackForm.rating}
                  onChange={(e) => setFeedbackForm({ ...feedbackForm, rating: Number(e.target.value) })}
                  className="w-full accent-cyan-500 bg-zinc-950 h-1.5 rounded-lg appearance-auto cursor-pointer"
                />
                <div className="flex justify-between text-[8px] font-mono text-zinc-550 pt-0.5">
                  <span>1 - INACCURATE</span>
                  <span>5 - FULLY ACCURATE</span>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-mono text-zinc-400 mb-1">FEEDBACK MESSAGE:</label>
                <textarea
                  required
                  rows={3}
                  value={feedbackForm.message}
                  onChange={(e) => setFeedbackForm({ ...feedbackForm, message: e.target.value })}
                  placeholder="Detail your experience with the scanner, false-positives spotted, or thoughts on threat matrices..."
                  className="w-full bg-zinc-950 border border-zinc-800 border-dashed rounded p-2.5 text-xs focus:outline-none focus:ring-1 focus:ring-cyan-500 text-white placeholder-zinc-650 resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-transparent border border-slate-705 text-white hover:bg-[#1a212e] rounded font-mono text-xs transition duration-150 cursor-pointer flex items-center justify-center space-x-1"
              >
                <Send className="w-3 h-3 text-cyan-400" />
                <span>WRITE TO DEFENSIVE REGISTRY</span>
              </button>
            </form>

            {/* List feedbacks live */}
            <div className="mt-5 pt-4 border-t border-zinc-850">
              <h4 className="text-[10px] font-mono uppercase text-zinc-450 tracking-wider mb-2">
                Recent Submission Logs ({feedbackList.length})
              </h4>
              
              {loadingFeedback ? (
                <div className="text-[10px] font-mono text-zinc-500 py-1">Loading feedback data...</div>
              ) : feedbackList.length === 0 ? (
                <div className="text-[10px] font-mono text-zinc-550 italic text-center p-2">
                  No feedback records registered yet. Give us a check mark write-up!
                </div>
              ) : (
                <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                  {feedbackList.slice(-3).reverse().map((f) => (
                    <div
                      key={f.id}
                      className="text-[10px] font-mono p-2.1 bg-zinc-950/70 border border-zinc-900 rounded p-2 text-zinc-300 leading-normal"
                    >
                      <div className="flex justify-between items-center text-[8px] text-zinc-500 mb-1">
                        <span className="font-bold text-zinc-400 truncate max-w-24">{f.name}</span>
                        <span className="text-cyan-400">★ {f.rating}/5</span>
                      </div>
                      <p className="text-[10px] font-sans text-zinc-400 break-words leading-tight">{f.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Secure Internship Submission Badge */}
          <div className="border border-slate-800/60 bg-zinc-950/60 rounded-xl p-4 flex flex-col space-y-1.5 select-none font-mono text-[11px] text-zinc-400">
            <div className="font-semibold text-white flex items-center space-x-1">
              <span className="text-cyan-450">⊞</span>
              <span>IBM Skills Showcase Track - Civil Eng.</span>
            </div>
            <div>
              <strong>Candidate Student:</strong> Darji Dev (Sem 5)
            </div>
            <div>
              <strong>Departmental Branch:</strong> Diploma Civil Engineering
            </div>
            <div>
              <strong>Verified Target:</strong> Phishing Web Detect Project
            </div>
            <div className="text-[10px] text-zinc-500 italic pt-0.5">
              *Self-contained demonstration containing real live lexical feedback streams, student registry, and heuristic intelligence filters.
            </div>
          </div>

        </div>

      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-900 bg-zinc-950/70 py-6 mt-12 text-center text-xs text-zinc-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>PHISHGUARD SECURE SERVER STABLE</span>
          </div>
          <div>
            Darji Dev • Diploma Civil Engineering Sem 5 Project Submission © {new Date().getFullYear()}
          </div>
        </div>
      </footer>

      {/* Dynamic Immersive Login Gateway Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm transition-all duration-200">
          <div className="relative w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl shadow-cyan-500/5 transition-transform duration-200">
            
            {/* Header gradient bar */}
            <div className="bg-gradient-to-r from-cyan-500 to-teal-500 h-1.5 w-full"></div>
            
            {/* Close button */}
            <button
              onClick={() => {
                setShowLoginModal(false);
                setLoginError("");
                setLoginSuccess("");
              }}
              className="absolute top-4 right-4 text-zinc-400 hover:text-white transition duration-150 p-1.5 bg-zinc-950/40 rounded-full border border-zinc-800/40"
              type="button"
            >
              <X className="w-3.5 h-3.5" />
            </button>

            <div className="p-6 sm:p-8">
              <div className="flex items-center space-x-3 mb-6">
                <div className="p-2 bg-cyan-500/10 rounded-xl text-cyan-400 border border-cyan-500/20">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white tracking-tight">Academic Identity Access</h3>
                  <p className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest">Cyber Security Portal Gateway</p>
                </div>
              </div>

              {loginError && (
                <div className="mb-4 p-3 rounded bg-rose-500/10 border border-rose-500/30 text-rose-450 text-xs font-mono">
                  {loginError}
                </div>
              )}

              {loginSuccess && (
                <div className="mb-4 p-3 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-450 text-xs font-mono">
                  {loginSuccess}
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-zinc-400 mb-1.5">
                    Authorized Academic Email:
                  </label>
                  <input
                    type="email"
                    required
                    value={loginForm.email}
                    onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                    placeholder="e.g. darji.dev.civil@example.com"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-cyan-500 text-white rounded-lg px-3 py-2 text-xs focus:outline-none transition duration-150"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-zinc-400 mb-1.5">
                    Secure Access Passcode/phrase:
                  </label>
                  <input
                    type="password"
                    required
                    value={loginForm.password}
                    onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                    placeholder="••••••••"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-cyan-500 text-white rounded-lg px-3 py-2 text-xs focus:outline-none transition duration-150"
                  />
                </div>

                <div className="bg-zinc-950 p-3 rounded border border-zinc-850 text-[10px] font-mono text-zinc-400 leading-relaxed">
                  <span className="text-cyan-400 font-bold block mb-0.5">&bull; DEMO CREDENTIAL ENTRY</span>
                  Input your academic email and any temporary secure passphrase of at least 5 characters to authorize simulated dashboards.
                </div>

                <div className="flex items-center justify-end pt-2">
                  <button
                    type="submit"
                    className="w-full sm:w-auto bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-405 hover:to-teal-405 text-zinc-950 font-bold font-mono text-xs px-5 py-2.5 rounded-lg transition duration-150 shadow-md flex items-center justify-center space-x-1.5"
                  >
                    <span>AUTHORIZE ACCESS</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
