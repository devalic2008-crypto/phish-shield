export interface PhishingAnalysis {
  verdict: 'safe' | 'suspicious' | 'phishing';
  riskScore: number;
  confidenceScore: number;
  threatType: string;
  detectedIndicators: string[];
  detailedExplanation: string;
  mitigationRecommendation: string;
  mode?: string;
}

export interface Feedback {
  id: string;
  name: string;
  email: string;
  rating: number;
  message: string;
  category: string;
  date: string;
}

export interface SignupProfile {
  id: string;
  name: string;
  email: string;
  role: string;
  interest: string;
  agreement: boolean;
  date: string;
}

export interface CyberStats {
  activeThreatsIndexed: number;
  commonAttacksToday: { name: string; count: number }[];
  verifiedSafeCount: number;
  scannerMetrics: {
    urlScanSuccess: string;
    aiRecallRate: string;
    falsePositives: string;
  };
}
